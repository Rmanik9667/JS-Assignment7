$(document).ready(function() {
	$("aside a").click(function(){
		var file = "";
		$("main").html("");
		if($(this).attr("title") == "toobin")
		{
			file = "json_files/toobin.json";
		}
		else if($(this).attr("title") == "sorkin")
		{
			file = "json_files/sorkin.json";
		}
		else if($(this).attr("title") == "chua")
		{
			file = "json_files/chua.json";
		}
		else if($(this).attr("title") == "sampson")
		{
			file = "json_files/sampson.json";
		}
		$.getJSON(file, function(data){
			$.each(data, function(){
				$.each(this, function(key, value){
					$("main").append(
						"<h1>" + value.title + "</h1><img src=" + value.image + "><h2>" + value.month + "<br>" + value.speaker + "</h2><p>" + value.text + "</p>"
					);
				});
			});
		});
	});
}); // end ready